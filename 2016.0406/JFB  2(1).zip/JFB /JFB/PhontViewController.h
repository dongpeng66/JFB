//
//  PhontViewController.h
//  JFB
//
//  Created by 积分宝 on 16/3/15.
//  Copyright © 2016年 李俊阳. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhontViewController : UIViewController
@property(nonatomic,strong,nullable) NSArray *photoArr;
@end
