//
//  CityObject.h
//  JFB
//
//  Created by JY on 15/8/27.
//  Copyright (c) 2015年 JY. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CityObject : NSObject

@property (strong, nonatomic) NSMutableArray *countysArray;
@property (strong, nonatomic) NSString *areaId;
@property (strong, nonatomic) NSString *areaName;
@property (strong, nonatomic) NSString *pyName;

@end
