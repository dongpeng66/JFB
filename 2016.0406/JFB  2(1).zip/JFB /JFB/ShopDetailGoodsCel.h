//
//  ShopDetailGoodsCel.h
//  JFB
//
//  Created by LYD on 15/9/2.
//  Copyright (c) 2015年 JY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShopDetailGoodsCel : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *emptyL;
@property (weak, nonatomic) IBOutlet UILabel *contentL;
@property (weak, nonatomic) IBOutlet UIWebView *contentWeb;

@end
