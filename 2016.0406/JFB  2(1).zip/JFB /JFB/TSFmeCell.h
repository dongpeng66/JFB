//
//  TSFmeCell.h
//  JFB
//
//  Created by 积分宝 on 15/12/3.
//  Copyright © 2015年 积分宝. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TSFmeCell : UITableViewCell
@property(nullable,nonatomic,strong) UIImageView *leftimageView;
@property(nullable,nonatomic,strong) UILabel *lab;
@end
