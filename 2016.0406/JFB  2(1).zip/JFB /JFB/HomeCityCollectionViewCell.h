//
//  HomeCityCollectionViewCell.h
//  JFB
//
//  Created by LYD on 15/8/27.
//  Copyright (c) 2015年 JY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeCityCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIButton *cityBtn;


@end
