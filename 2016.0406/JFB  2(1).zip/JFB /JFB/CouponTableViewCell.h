//
//  CouponTableViewCell.h
//  JFB
//
//  Created by LYD on 15/9/23.
//  Copyright © 2015年 JY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CouponTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *couponNoL;
@property (weak, nonatomic) IBOutlet UILabel *couponCodeL;

@end
