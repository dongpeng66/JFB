//
//  MerchantAlbumCollectionViewCell.h
//  JFB
//
//  Created by LYD on 15/9/16.
//  Copyright (c) 2015年 JY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MerchantAlbumCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIButton *AlbumBtn;
@property (weak, nonatomic) IBOutlet UILabel *titleL;
@end
