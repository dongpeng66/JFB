//
//  NSString+DPStringSize.h
//  JFB
//
//  Created by IOS on 16/3/17.
//  Copyright © 2016年 李俊阳. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (DPStringSize)

-(CGSize)stringGetSizeWithFont:(CGFloat)font;
@end
