//
//  CityDistrictsCoreObject+CoreDataProperties.m
//  JFB
//
//  Created by LYD on 15/9/28.
//  Copyright © 2015年 JY. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "CityDistrictsCoreObject+CoreDataProperties.h"

@implementation CityDistrictsCoreObject (CoreDataProperties)

@dynamic isopen;
@dynamic areaId;
@dynamic areaName;
@dynamic pyName;
@dynamic level;
@dynamic current_code;
@dynamic parentID;

@end
