//
//  CityDistrictsCoreObject.m
//  JFB
//
//  Created by LYD on 15/9/28.
//  Copyright © 2015年 JY. All rights reserved.
//

#import "CityDistrictsCoreObject.h"
#import "AppDelegate.h"

@implementation CityDistrictsCoreObject

// Insert code here to add functionality to your managed object subclas


@end
