//
//  TitleVIew.h
//  头部选择
//
//  Created by 积分宝 on 16/3/18.
//  Copyright © 2016年 积分宝. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TitleVIew : UIView
@property (nonatomic,strong) UIButton *saoMaBtn;
@property (nonatomic,strong) UIButton *searchBtn;
@end
