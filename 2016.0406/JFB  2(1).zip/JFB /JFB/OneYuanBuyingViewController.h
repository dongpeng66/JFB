//
//  OneYuanBuyingViewController.h
//  JFB
//
//  Created by 积分宝 on 16/4/6.
//  Copyright © 2016年 李俊阳. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OneYuanBuyingViewController : UIViewController

@end
