//
//  SpecialtyGoodsView.h
//  特产首页
//
//  Created by 想牵着你的手 on 15-12-22.
//  Copyright (c) 2015年 积分宝. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SpecialtyGoodsView : UIView
@property (nonatomic,strong) NSMutableAttributedString *pricelText;
@property (nonatomic,strong) UILabel *priceL;
@property (nonatomic,strong) UILabel *goodsNameL;
@property (nonatomic,strong) UIImageView *goodsIM;
@property (nonatomic,strong) UIButton *buyBtn;
@end
