//
//  SumOneCell.h
//  原来如此
//
//  Created by 积分宝 on 16/1/21.
//  Copyright © 2016年 积分宝. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SumOneCell : UITableViewCell
@property (nonatomic,strong) UILabel *nameL;//姓名
@property (nonatomic,strong) UILabel *numberL;//电话
@property (nonatomic,strong) UILabel *dizhi;//地址
@property (nonatomic,strong) UIButton *addDiBtn;
@end
