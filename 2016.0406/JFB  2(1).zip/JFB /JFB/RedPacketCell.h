//
//  RedPacketCell.h
//  红包
//
//  Created by 积分宝 on 15/12/11.
//  Copyright © 2015年 积分宝. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RedPacketCell : UITableViewCell
@property (nullable,nonatomic,strong) UIImageView *beiJingView;
@property (nonatomic,nullable,strong) UIImageView *hongBaoView;
@property (nullable,nonatomic,strong) UILabel *shuXianL;
@property (nullable,nonatomic,strong) UILabel *hongBaoL;
@property (nullable,nonatomic,strong) UILabel *keYongL;
@property (nullable,nonatomic,strong) UILabel *xianHaoL;
@property (nullable,nonatomic,strong) UILabel *riQiL;

@end
