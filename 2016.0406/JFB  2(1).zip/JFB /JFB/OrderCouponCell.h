//
//  OrderCouponCell.h
//  JFB
//
//  Created by JY on 15/9/26.
//  Copyright (c) 2015年 JY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OrderCouponCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIButton *consume_codeBtn;
@property (weak, nonatomic) IBOutlet UILabel *statusL;

@end
