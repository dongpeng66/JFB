//
//  CollectionTableViewCell.h
//  JFB
//
//  Created by JY on 15/9/9.
//  Copyright (c) 2015年 JY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionTableViewCell : UITableViewCell

@end
