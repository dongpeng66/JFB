//
//  MerchantAlbumCollectionViewCell.m
//  JFB
//
//  Created by LYD on 15/9/16.
//  Copyright (c) 2015年 JY. All rights reserved.
//

#import "MerchantAlbumCollectionViewCell.h"

@implementation MerchantAlbumCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
    self.layer.borderWidth = 3;
    self.layer.borderColor = [UIColor whiteColor].CGColor;
}

@end
