//
//  RoutePlanTableViewCell.h
//  JFB
//
//  Created by LYD on 15/9/21.
//  Copyright © 2015年 JY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RoutePlanTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *numberL;
@property (weak, nonatomic) IBOutlet UILabel *routeNameL;
@property (weak, nonatomic) IBOutlet UILabel *routeDetailL;
@end
