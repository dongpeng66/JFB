//
//  ShopSearchViewController.h
//  JFB
//
//  Created by JY on 15/8/29.
//  Copyright (c) 2015年 JY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShopSearchViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITableView *myTableView;
@property (weak, nonatomic) IBOutlet UITableView *historyTableView;
@end
