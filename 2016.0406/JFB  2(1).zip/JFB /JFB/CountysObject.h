//
//  CountysObject.h
//  JFB
//
//  Created by JY on 15/8/27.
//  Copyright (c) 2015年 JY. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CountysObject : NSObject

@property (strong, nonatomic) NSString *countId;
@property (strong, nonatomic) NSString *countName;
@property (strong, nonatomic) NSString *countPyName;

@end
