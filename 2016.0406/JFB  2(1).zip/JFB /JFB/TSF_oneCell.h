//
//  TSF_oneCell.h
//  nimabi
//
//  Created by 积分宝 on 15/12/22.
//  Copyright © 2015年 积分宝. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MoneyView.h"
@interface TSF_oneCell : UITableViewCell
@property (nullable,nonatomic,strong) UIImageView *bigIM;

@end
