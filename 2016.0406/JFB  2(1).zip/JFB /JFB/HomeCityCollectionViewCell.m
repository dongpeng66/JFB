//
//  HomeCityCollectionViewCell.m
//  JFB
//
//  Created by LYD on 15/8/27.
//  Copyright (c) 2015年 JY. All rights reserved.
//

#import "HomeCityCollectionViewCell.h"

@implementation HomeCityCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
    self.cityBtn.selected = NO;
}


@end
