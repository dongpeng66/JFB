//
//  TabBarController.h
//  JFB
//
//  Created by JY on 15/8/13.
//  Copyright (c) 2015年 JY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabBarController : UITabBarController

@end
