//
//  OrderRefundSuccessViewController.h
//  JFB
//
//  Created by LYD on 15/9/25.
//  Copyright © 2015年 JY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OrderRefundSuccessViewController : UIViewController

@end
