//
//  Specialty.h
//  特产首页
//
//  Created by 积分宝 on 15/12/22.
//  Copyright © 2015年 积分宝. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Specialty : UIViewController
@property (nullable,nonatomic,strong)NSArray *countysArray;  //区县数组
@property (nullable,nonatomic,strong)NSString *cityName;
@end
