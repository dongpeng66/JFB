//
//  goodsDetailDescriptionCell.h
//  JFB
//
//  Created by IOS on 16/3/16.
//  Copyright © 2016年 李俊阳. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface goodsDetailDescriptionCell : UITableViewCell
//商品名称
@property (nonatomic,strong) UILabel *goodsNameLabel;
//商品描述
@property (nonatomic,strong) UILabel *goodsDescriptionLabel;
//
@property (nonatomic,strong) UIImageView *myImageView;
@end
