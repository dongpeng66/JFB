//
//  RoutePlanTableViewCell.m
//  JFB
//
//  Created by LYD on 15/9/21.
//  Copyright © 2015年 JY. All rights reserved.
//

#import "RoutePlanTableViewCell.h"

@implementation RoutePlanTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
