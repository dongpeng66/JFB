//
//  HomeShopListCell.m
//  JFB
//
//  Created by LYD on 15/8/18.
//  Copyright (c) 2015年 JY. All rights reserved.
//

#import "HomeShopListCell.h"

@implementation HomeShopListCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
