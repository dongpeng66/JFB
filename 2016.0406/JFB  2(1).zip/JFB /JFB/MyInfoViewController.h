//
//  MyInfoViewController.h
//  JFB
//
//  Created by LYD on 15/8/20.
//  Copyright (c) 2015年 JY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyInfoViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITableView *myTableView;
@end
