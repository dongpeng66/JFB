//
//  MyEvaluateViewController.h
//  JFB
//
//  Created by JY on 15/8/24.
//  Copyright (c) 2015年 JY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyEvaluateViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITableView *myTableView;
@end
