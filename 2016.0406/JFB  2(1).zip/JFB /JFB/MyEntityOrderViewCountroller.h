//
//  MyEntityOrderViewCountroller.h
//  JFB
//
//  Created by 积分宝 on 15/12/24.
//  Copyright © 2015年 李俊阳. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyEntityOrderViewCountroller : UIViewController
@property (strong, nonatomic) UITableView *myTableView;
@property (strong, nonatomic) NSString * fraction;
@end
