//
//  OrderForeCell.h
//  订单详情
//
//  Created by 积分宝 on 16/1/7.
//  Copyright © 2016年 积分宝. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OrderForeCell : UITableViewCell
@property (nonatomic,strong) UILabel *lab1;
@property (nonatomic,strong) UILabel *lab2;
@property (nonatomic,strong) UILabel *lab3;
@property (nonatomic,strong) UILabel *lab4;
@property (nonatomic,strong) UILabel *lab5;
@property (nonatomic,strong) UILabel *lab6;
@property (nonatomic,strong) UILabel *lab7;
@property (nonatomic,strong) UILabel *lab8;
@property (nonatomic,strong) UILabel *copysL;
@property (nonatomic,strong) UIButton *copysBtn;
@end
