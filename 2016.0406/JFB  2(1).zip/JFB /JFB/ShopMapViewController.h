//
//  ShopMapViewController.h
//  JFB
//
//  Created by JY on 15/8/29.
//  Copyright (c) 2015年 JY. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <BaiduMapAPI/BMapKit.h>//引入所有的头文件

@interface ShopMapViewController : UIViewController <BMKLocationServiceDelegate,BMKMapViewDelegate>

@end
