//
//  AboutUsViewController.h
//  JFB
//
//  Created by 积分宝 on 16/3/4.
//  Copyright © 2016年 李俊阳. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutUsViewController : UIViewController
@property (nonatomic,strong) NSString *type;
@end
