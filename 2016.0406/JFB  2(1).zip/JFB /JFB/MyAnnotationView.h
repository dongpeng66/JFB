//
//  MyAnnotationView.h
//  JFB
//
//  Created by LYD on 15/9/6.
//  Copyright (c) 2015年 JY. All rights reserved.
//

#import <BaiduMapAPI/BMKAnnotationView.h>

@interface MyAnnotationView : BMKAnnotationView

@end
