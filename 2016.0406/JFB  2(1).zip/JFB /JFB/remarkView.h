//
//  remarkView.h
//  自定义提示
//
//  Created by 积分宝 on 16/2/22.
//  Copyright © 2016年 积分宝. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface remarkView : UIView
@property (nonatomic,strong) UITextView *filed;
@property (nonatomic,strong) UIButton *leftBtn;
@property (nonatomic,strong) UIButton *rightBtn;
@end
